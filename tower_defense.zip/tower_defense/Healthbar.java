import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
/**
 * Represent the healthbar on top of monster and tower.
 *
 * @author Yixin Sun
 * @version 1.0
 */

public class Healthbar extends Group {
    private Rectangle red, green;
    /**
     * Constructs the healthbar object.
     *@param x xcoordinate
     *@param y yCoordinate
     *@param w width of the healthbar
     *@param h height of the healthbar
     */
    public Healthbar(double x, double y, int w, int h) {
        green = new Rectangle();
        green.setFill(Color.GREEN);
        red = new Rectangle();
        red.setFill(Color.RED);
        setPos(x, y);
        green.setWidth(w);
        green.setHeight(h);
        green.setVisible(true);
        red.setWidth(w);
        red.setHeight(h);
        red.setVisible(true);
        getChildren().addAll(red, green);
    }
    /**
     * set the position of the healthbar
     * @param x xCoordinate
     * @param y yCoordinate
     */
    public void setPos(double x, double y) {
        green.setX(x);
        green.setY(y);
        red.setX(x);
        red.setY(y);
    }
    /**
     * get the red rectangle
     * @return red
     */
    public Rectangle getRed() {
        return red;
    }
    /**
     * get the green rectangle
     * @return green
     */
    public Rectangle getGreen() {
        return green;
    }
}
