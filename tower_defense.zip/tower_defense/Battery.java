import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
/**
 * Builds Battery based on given position and gives a bomb to kill the monster
 *
 * @author Yixin Sun
 * @version 1.0
 */
public class Battery {
    private static Image launcher = new Image("pics/launcher.png");
    private ImageView base;
    private static int score = 100;
    private static int cost = 20;
    private double xCoord, yCoord;
    /**
     * Constructs the Battery object with it's imageview.
     * @param x the x coordinate of battery
     * @param y the y coordinate of battery
     */
    public Battery(double x, double y) {
        if (score > 0) {
            score -= cost;
            xCoord = x;
            yCoord = y;
            base = new ImageView(Battery.launcher);
            base.setX(x);
            base.setY(y);
        }
    }
    /**
     * Get the Battery's x.
     *
     * @return xCoord
     */
    public double getX() {
        return xCoord;
    }
     /**
     * Get the Battery's Y.
     *
     * @return YCoord
     */
    public double getY() {
        return yCoord;
    }
    /**
     * Get the Battery's image.
     *
     * @return base
     */
    public ImageView getImage() {
        return base;
    }
    /**
     * Get the Battery's score.
     *
     * @return score
     */
    public int getScore() {
        return score;
    }
}
