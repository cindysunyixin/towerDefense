import java.util.ArrayList;
import java.util.Random;
import javafx.animation.PathTransition;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.HLineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.VLineTo;
import javafx.util.Duration;
/**
 * Represent an abstract monster.
 *
 * @author Yixin Sun
 * @version 1.0
 */
public abstract class Monster {
    protected int hp;
    protected int atk;
    protected ImageView monImg;
    protected static int xIni = 0;
    protected static int yIni = 430;
    protected ArrayList<Image> img;
    protected boolean isDead = false;
    protected static int score;
    protected Group monandHP;
    /**
     * Constructs the monster.
     *@param hp the initial hp of monster
     *@param atk the amount of attack on target tower
     */
    public Monster(int hp, int atk) {

        if (hp >= 0) {
            this.hp = hp;
        }
        this.atk = atk;
        isDead = false;
        upLoadpic();
        monandHP = group();
    }
    /**
     * Get the monster's health.
     *
     * @return hp
     */
    public int getHP() {
        return hp;
    }
    /**
     * Get the monster's attack.
     *
     * @return atk
     */
    public int getAtk() {
        return atk;
    }
    /**
     * Get the game's score
     *
     * @return score
     */
    public int getScore() {
        return score;
    }
    /**
     * Get the boolean of monster's death
     *
     * @return isDead
     */
    public boolean dead() {
        if (hp <= 0) {
            isDead = true;
            score += 10;
            return isDead;
        } else {
            isDead = false;
            return isDead;
        }
    }
    /**
     * Get the picture of the monster
     *
     * @return monImg
     */
    public ImageView getPic() {
        return monImg;
    }
    /**
     * Randomly Get one monster picture from the documents
     *
     * @return a the imageview of the img
     */
    public ImageView getImg() {
        ImageView a = new ImageView();
        Random r = new Random();
        Image aa = img.get(r.nextInt(img.size()));
        a.setImage(aa);
        a.setX(Monster.xIni);
        a.setY(Monster.yIni);
        return a;
    }
    /**
     * getting hurt form the bomb
     * @param kill the amount of damage from the bomb
     */
    public void hurt(int kill) {
        hp = hp - kill;
    }
    /**
     * upload the picture from documents
     * @return img the arraylist of image
     */
    public ArrayList<Image> upLoadpic() {
        img = new ArrayList<>();
        img.add(new Image("/pics/Pixel-Alien-1.png"));
        img.add(new Image("/pics/Pixel-Alien-2.png"));
        img.add(new Image("/pics/Pixel-Alien-3.png"));
        img.add(new Image("/pics/Pixel-Alien-4.png"));
        img.add(new Image("/pics/Pixel-Alien-5.png"));
        img.add(new Image("/pics/Pixel-Alien-6.png"));
        img.add(new Image("/pics/Pixel-Alien-7.png"));
        img.add(new Image("/pics/Pixel-Alien-8.png"));
        img.add(new Image("/pics/Pixel-Alien-9.png"));
        img.add(new Image("/pics/Pixel-Alien-10.png"));
        img.add(new Image("/pics/Pixel-Alien-11.png"));
        img.add(new Image("/pics/Pixel-Alien-12.png"));
        return img;
    }
    /**
     * make the monster move
     */
    public void move() {
        PathTransition pathTransition = new PathTransition();
        pathTransition.setDuration(Duration.millis(20000));
        pathTransition.setPath(road());
        pathTransition.setNode(getGroup());
        pathTransition.setOrientation(
            PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pathTransition.play();
    }
    /**
     * make a group of monster and its healthbar
     * @return aMonHP
     */
    public Group group() {
        Group aMonHP = new Group();
        Healthbar monHP = new Healthbar(getImg().getX(),
            getImg().getY(), 64, 10);
        aMonHP.getChildren().addAll(getImg(), monHP);
        return aMonHP;
    }
    /**
     * get the group of monster and its hp
     * @return monandHP
     */
    public Group getGroup() {
        return monandHP;
    }
    /**
     * Make the path for the monster to move
     * @return path the path of moving
     */
    public Path road() {
        HLineTo h1 = new HLineTo(84);
        VLineTo v1 = new VLineTo(84);
        HLineTo h2 = new HLineTo(280);
        VLineTo v2 = new VLineTo(690);
        HLineTo h3 = new HLineTo(360);
        VLineTo v3 = new VLineTo(610);
        HLineTo h4 = new HLineTo(800);
        VLineTo v4 = new VLineTo(400);
        HLineTo h5 = new HLineTo(1120);
        VLineTo v5 = new VLineTo(300);
        HLineTo vf = new HLineTo(1121);

        Path path = new Path();
        path.getElements().addAll(new MoveTo(40, 430),
                h1, v1, h2, v2, h3, v3,
                h4, v4, h5, v5,
                vf);
        return path;
    }
    /**
     * attack the target tower
     * @param target the targeted tower
     */
    public abstract void attack(Tower target);

}
