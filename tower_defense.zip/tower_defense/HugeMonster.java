/**
 * Represent a huge monster.
 *
 * @author Yixin Sun
 * @version 1.0
 */
public class HugeMonster extends Monster {
    /**
     * Constructs the hugemonster object.
     */
    public HugeMonster() {
        super(200, 20);
    }
    /**
     * attack the tower
     *@param target the targeted tower for kill
     */
    public void attack(Tower target) {
        target.hurt(atk);
    }
}
