import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
/**
 * Represent a Try class.
 *
 * @author Yixin Sun
 * @version 1.0
 */
public class Try extends Application {
    private static int width = 1376, length = 736;
    private static int blockSize = 64;
    private Healthbar towerhp;
/**
@param
*/
    public Try() {

    }
/**
@param s stage
*/

    public void start(Stage s) {
        s.setTitle("Tower defense");
        Group root = new Map();
        towerhp = new Healthbar(1025, 35, 190, 15);
        Group ri = plantable();
        root.getChildren().add(towerhp);
        ImageView house = new ImageView(new Image(
            "/pics/MapCroppedForeground.png"));
        Group houseAndbg = new Group(root, house, ri);
        nextWave(root);
        ri.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                try {
                    for (int a = 0; a < 20; a++) {
                        for (int b = 0; b < 11; b++) {
                            int lowerX = a * blockSize + 32;
                            int higherX = (a + 1) * blockSize + 32;
                            int lowerY = b * blockSize + 32;
                            int higherY = (b + 1) * blockSize + 32;
                            if (e.getX() > lowerX && e.getX() < higherX
                                && e.getY() < higherY && e.getY() > lowerY) {
                                System.out.println("" + lowerX + " " + lowerY);
                                ri.getChildren().add(plant(lowerX, lowerY));



                            }
                        }
                    }
                } catch (Exception aEx) {
                    String aS = "1";
                }
            });

        StackPane r = new StackPane();
        r.getChildren().add(houseAndbg);
        Scene scene = new Scene(r, width, length);
        s.setScene(scene);
        s.show();
    }
/**
@param args args
*/
    public static void main(String[] args) {
        launch(args);
    }
/**
@param x x
@param y y
@return base
*/

    public ImageView plant(double x, double y) {
        Battery b = new Battery(x, y);
        ImageView base = b.getImage();
        return base;
    }
/**
@return ab
*/
    public Group spawn() {
        Group ab = null;
        Monster a = new NoobMonster();
        try {
            ab = a.getGroup();
            a.move();
        } catch (Exception e) {
            System.out.println("there's no such pic.");
        }
        return ab;

    }
/**
@param gg gg
*/
    public void nextWave(Group gg) {
        Timeline timeline = new Timeline(new KeyFrame(
                Duration.millis(1000),
                ae -> gg.getChildren().add(spawn())));
        timeline.setCycleCount(10);
        timeline.play();
    }
/**
@return plantPlace
*/
    public Group plantable() {
        Group plantPlace = new Group();
        for (int i = 32; i < 1376;) {
            for (int j = 32; j < 736;) {
                Rectangle plant = new Rectangle(64, 64);
                plant.setFill(Color.TRANSPARENT);
                plant.setStroke(Color.TRANSPARENT);
                plant.setX(i);
                plant.setY(j);
                plantPlace.getChildren().add(plant);
                j += 64;
            }
            i += 64;
        }
        return plantPlace;
    }
/**
@param x x
@param y y
@return a boolean
*/
    public boolean isInBlock(double x, double y) {
        for (int a = 0; a < 20; a++) {
            for (int b = 0; b < 11; b++) {
                int lowerX = a * blockSize + 32;
                int higherX = (a + 1) * blockSize + 32;
                int lowerY = b * blockSize + 32;
                int higherY = (b + 1) * blockSize + 32;
                if (x > lowerX && x < higherX
                    && y < higherY && y > lowerY) {
                    System.out.println(" " + lowerX + " " + lowerY);
                    return true;
                }
            }
        }
        return false;
    }

}
