/**
 * Represent a NoobMonster.
 *
 * @author Yixin Sun
 * @version 1.0
 */
public class NoobMonster extends Monster {
    /**
     * Constructs the Noobmonster.
     */
    public NoobMonster() {
        super(100, 10);
    }
    /**
     * attack the target tower
     * @param target the targeted tower
     */
    public void attack(Tower target) {
        target.hurt(atk);
    }
}
