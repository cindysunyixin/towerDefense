import javafx.scene.text.Text;
/**
 * Represent a tower.
 *
 * @author Yixin Sun
 * @version 1.0
 */

public class Tower {
    private int hp;
    private boolean gameIsOver = false;
    private Text towerHP;
    /**
     * Constructs the tower with an initial hp of 1000
     */
    public Tower() {
        setHP(1000);
    }
    /**
     * set the tower's health.
     * @param i the health for tower
     */
    public void setHP(int i) {
        hp = i;
    }
    /**
     * Get the tower's health.
     *
     * @return hp
     */
    public int getHP() {
        return hp;
    }
    /**
     * get hurt from the monster
     * @param atk the amount of damage from the monster
     */
    public void hurt(int atk) {
        hp = hp - atk;
    }
    /**
     * heal itself if nobody attacks
     *
     */
    public void heal() {
        hp++;
    }
    /**
     * get the text of hp
     * @return towerHP
     */
    public Text health() {
        towerHP.setText("" + getHP());
        return towerHP;
    }
    /**
     * get the boolean of tower's death
     *
     * @return gameIsOver;
     */
    public boolean gameOver() {
        if (hp == 0) {
            gameIsOver = true;
            return gameIsOver;
        } else {
            gameIsOver = false;
            return gameIsOver;
        }
    }

}
