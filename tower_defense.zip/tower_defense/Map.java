import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Represent a Map object.
 *
 * @author Yixin Sun
 * @version 1.0
 */
public class Map extends Group {
    private Image map;

    /**
     * Constructs the Map with its image
     */
    public Map() {
        try {
            map =  new Image("/pics/MapCropped.png");
        } catch (Exception e) {
            System.out.println("aha");
        }
        ImageView bg = new ImageView();
        bg.setImage(map);
        getChildren().add(bg);
    }
}
