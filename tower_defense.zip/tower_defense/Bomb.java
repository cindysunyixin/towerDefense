import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
/**
 * Represent a Bomb.
 *
 * @author Yixin Sun
 * @version 1.0
 */
public class Bomb {
    private int kill;
    private static ImageView bomb = new ImageView(new Image("/pics/bomb.gif"));
    /**
     * Constructs the Bomb object.
     * @param kill the amount of damage on monster
     */
    public Bomb(int kill) {
        this.kill = kill;
    }
    /**
     * Constructs the Bomb object.
     * @param target the targeted monster
     */
    public void hurt(Monster target) {
        target.hurt(kill);
    }
    /**
     * get the amont of damage on monster
     * @return kill
     */
    public int getKill() {
        return kill;
    }
    /**
     * get the image of the bomb
     * @return bomb
     */
    public ImageView getImg() {
        return bomb;
    }

}
